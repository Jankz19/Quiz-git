
// både counterstrike och league of legends frågorna seperata
const csQuestions = [
    {
        question: "Vilket år släpptes det första Counter-Strike?",
        answers: [
            { text: "1999", correct: true },
            { text: "2001", correct: false },
            { text: "2003", correct: false },
            { text: "1998", correct: false }
        ]
    },
    {
        question: "Vilket företag utvecklade Counter-Strike?",
        answers: [
            { text: "Valve", correct: true },
            { text: "Blizzard", correct: false },
            { text: "Riot Games", correct: false },
            { text: "Ubisoft", correct: false }
        ]
    },
    {
        question: "Vad heter bombplatserna på Dust2?",
        answers: [
            { text: "A och B", correct: true },
            { text: "C och D", correct: false },
            { text: "Alpha och Bravo", correct: false },
            { text: "X och Y", correct: false }
        ]
    },
    {
        question: "Vilken är standardpistolen för terrorister?",
        answers: [
            { text: "Glock-18", correct: true },
            { text: "P2000", correct: false },
            { text: "USP-S", correct: false },
            { text: "Desert Eagle", correct: false }
        ]
    },
    {
        question: "Vilken karta är den mest spelade i tävlingssammanhang?",
        answers: [
            { text: "Dust2", correct: true },
            { text: "Inferno", correct: false },
            { text: "Nuke", correct: false },
            { text: "Mirage", correct: false }
        ]
    }
];

const lolQuestions = [
    {
        question: "Vilket år släpptes League of Legends?",
        answers: [
            { text: "2009", correct: true },
            { text: "2011", correct: false },
            { text: "2007", correct: false },
            { text: "2013", correct: false }
        ]
    },
    {
        question: "Vilken är huvudstaden i Demacia?",
        answers: [
            { text: "Noxus", correct: false },
            { text: "Ionia", correct: false },
            { text: "Piltover", correct: false },
            { text: "Demacia City", correct: true }
        ]
    },
    {
        question: "Vad heter världsmästerskapet i League of Legends?",
        answers: [
            { text: "World Finals", correct: false },
            { text: "League Finals", correct: false },
            { text: "World Championship", correct: true },
            { text: "Summoner's Cup", correct: false }
        ]
    },
    {
        question: "Vilken champion är känd som 'The Sinister Blade'?",
        answers: [
            { text: "Ahri", correct: false },
            { text: "Katarina", correct: true },
            { text: "Zed", correct: false },
            { text: "Riven", correct: false }
        ]
    },
    {
        question: "Vilken är den högsta ranken i spelet?",
        answers: [
            { text: "Diamond", correct: false },
            { text: "Platinum", correct: false },
            { text: "Challenger", correct: true },
            { text: "Master", correct: false }
        ]
    }
];

let currentQuestionIndex = 0;
let score = 0;
let timer;
let timePerQuestion = 10; 
let totalTime = 0;
let startTime;
let selectedQuestions = [];
let quizTitle = '';

const startContainer = document.getElementById('start-container');
const quizContainer = document.getElementById('quiz-container');
const resultContainer = document.getElementById('result-container');
const questionContainer = document.getElementById('question-container');
const answerButtons = document.getElementById('answer-buttons');
const nextButton = document.getElementById('next-btn');
const resultElement = document.getElementById('result');
const timerElement = document.getElementById('timer');
const quizTitleElement = document.getElementById('quiz-title');

// Slumpa fram 5 frågor
function shuffleQuestions(quiz) {
    return quiz.sort(() => Math.random() - 0.5).slice(0, 5);
}

// när man startar quizet :D lets go !
function startQuiz(quizType) {
    if (quizType === 'cs') {
        selectedQuestions = shuffleQuestions(csQuestions);
        quizTitle = 'Counter Strike Quiz';
    } else if (quizType === 'lol') {
        selectedQuestions = shuffleQuestions(lolQuestions);
        quizTitle = 'League of Legends Quiz';
    }

    currentQuestionIndex = 0;
    score = 0;
    totalTime = 0;
    startTime = Date.now(); 
    nextButton.classList.add('hide');
    startContainer.classList.add('hide');
    quizContainer.classList.remove('hide');
    quizTitleElement.innerText = quizTitle;
    showQuestion(selectedQuestions[currentQuestionIndex]);
}


function showQuestion(question) {
    resetState();
    questionContainer.innerText = question.question;
    question.answers.forEach(answer => {
        const button = document.createElement('button');
        button.innerText = answer.text;
        button.classList.add('btn');
        button.dataset.correct = answer.correct;
        button.addEventListener('click', selectAnswer);
        answerButtons.appendChild(button);
    });
    startTimer();
}

// Återställ state
function resetState() {
    clearInterval(timer);
    nextButton.classList.add('hide');
    timerElement.innerText = `Time left: ${timePerQuestion}`;
    while (answerButtons.firstChild) {
        answerButtons.removeChild(answerButtons.firstChild);
    }
}


function startTimer() {
    let timeLeft = timePerQuestion;
    timer = setInterval(() => {
        timeLeft--;
        timerElement.innerText = `Time left: ${timeLeft}`;
        if (timeLeft === 0) {
            clearInterval(timer);
            goToNextQuestion(); // slut på tiden nästa fråga
        }
    }, 1000);
}


function selectAnswer(e) {
    const selectedButton = e.target;
    const correct = selectedButton.dataset.correct === 'true';
    if (correct) {
        score++;
        selectedButton.classList.add('correct');
    } else {
        selectedButton.classList.add('wrong');
    }
    Array.from(answerButtons.children).forEach(button => {
        button.disabled = true; // 1
        setStatusClass(button, button.dataset.correct);
    });
    clearInterval(timer);
    nextButton.classList.remove('hide');
}


function setStatusClass(element, correct) {
    if (correct === 'true') {
        element.classList.add('correct');
    } else {
        element.classList.add('wrong');
    }
}

// Funktion för att gå till nästa fråga eller avsluta quiz
function goToNextQuestion() {
    currentQuestionIndex++;
    if (currentQuestionIndex < selectedQuestions.length) {
        showQuestion(selectedQuestions[currentQuestionIndex]);
    } else {
        endQuiz();
    }
}

// Avsluta quizet och visa resultat
function endQuiz() {
    totalTime = Math.floor((Date.now() - startTime) / 1000); // Mät totaltid
    quizContainer.classList.add('hide');
    resultContainer.classList.remove('hide');
    resultElement.textContent = `You got ${score} out of 5 correct in ${totalTime} seconds!`;
}

// Koppla knappen till att gå till nästa fråga manuellt eller om tiden går ut
nextButton.addEventListener('click', goToNextQuestion);
